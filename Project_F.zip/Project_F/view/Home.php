s<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Online Learning Management System</title>
    <link rel="stylesheet" href="../css/home.css"> 
</head>
<body>
<?php require('navbar.php'); ?>

    <main>
        <section class="hero">
            <h2>Welcome to EDUCATIONAL NETWORKING LANDSCAPE!</h2>
            <p>Your gateway to a world of knowledge and learning.</p>
            <a href="courses.php" class="btn">Explore Courses</a>
            <a href="registration.php" class="btn">Get Started</a>
        </section>

       
            </div>
        </section>
    </main>


</body>
</html>