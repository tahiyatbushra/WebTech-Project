<?php
include_once("../model/db.php"); 

$courses = getOfferedCourses();
?>
